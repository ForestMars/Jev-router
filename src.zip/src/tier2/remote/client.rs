use tonic::transport::Channel;
use crate::tier2::remote::proto::{tier2_scorer_client::Tier2ScorerClient, ScoreRequest};

pub struct RemoteTier2 {
    client: Tier2ScorerClient<Channel>,
    model_id: String,
}

impl RemoteTier2 {
    pub async fn connect(endpoint: String, model_id: String) -> Result<Self, tonic::transport::Error> {
        Ok(Self {
            client: Tier2ScorerClient::connect(endpoint).await?,
            model_id,
        })
    }

    pub async fn score(&mut self, prompt: &str) -> Result<f32, tonic::Status> {
        let resp = self.client
            .score(ScoreRequest { prompt: prompt.to_string() })
            .await?
            .into_inner();
        Ok(resp.confidence)
    }
}
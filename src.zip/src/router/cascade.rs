pub async fn route(prompt: &str, tier2: &mut dyn Tier2Model) -> Decision {
    // Tier 1: deterministic (stub for now)
    if let Some(d) = tier1_check(prompt) { return d; }

    // Tier 2: call sidecar
    match tier2.score(prompt).await {
        Ok(result) if result.confidence >= 0.5 => {
            return Decision::new(&result.label, &result.model_id);
        }
        _ => {} // fall through to Tier 3
    }

    // Tier 3: Jev (stub)
    Decision::new("jev", "tier3")
}